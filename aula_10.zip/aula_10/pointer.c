#include <stdio.h>

int main(){
    char *s;
    *s = "Ola mundo";  
    printf("%s\n", s);
    return 0;
}

//implemntar a função calloc e a função free
