typedef unsigned char uint8;// 1 byte 0 a 255 
typedef unsigned short uint16;// 2 bytes 0 a 65.535
typedef unsigned int uint32;// 4 bytes 0 a 4.294.967.295
typedef unsigned long long uint64;// 8 bytes 0 a 18.446.744.073.709.551.615 = 18 quintilhões

