int main() {
     int v[1000][1000][1000];
     v[0][0][0] = 1;
     return 0;
}
