#define CLS "\x1B[2J"
#define TOP_LEFT "\x1B[H" // Move cursor para canto superior esquerdo
#define ORANGE "\x1B[38;2;255;165;0m"  //cor de texto
#define RESET_COLOR "\x1B[0m" //cor padrão 
#define PURPLE "\x1B[38;2;189;147;249m"

#define BOLD "\x1B[1m" 